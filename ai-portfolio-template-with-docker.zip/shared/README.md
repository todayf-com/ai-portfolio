# Shared

Wspólne skrypty/konfiguracje dla projektów.