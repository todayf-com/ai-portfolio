# Code of Conduct

Zachowuj kulturę, szanuj współtwórców. Nie akceptujemy mowy nienawiści ani spamu.
