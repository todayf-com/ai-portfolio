# Checklist — Zadania

- [ ] MVP: dialog z użytkownikiem (1 temat nauki)
- [ ] Personalizacja poziomu trudności
- [ ] Pamięć sesji i historia
- [ ] Baza pytań/quizów i ocena postępów
- [ ] Panel do konfiguracji ścieżek nauki
