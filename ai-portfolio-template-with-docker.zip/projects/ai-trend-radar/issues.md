# Checklist — Zadania

- [ ] MVP: pobieranie 5–10 artykułów dziennie
- [ ] Streszczenia + tagowanie tematów
- [ ] Generowanie raportu tygodniowego
- [ ] Dashboard (filtry, wyszukiwarka)
- [ ] Harmonogram (cron) i logi
