# Checklist — Zadania

- [ ] MVP: upload dokumentu (PDF)
- [ ] Streszczenie w języku prostym
- [ ] Wypunktowanie klauzul ryzyka
- [ ] Porównanie 2 dokumentów
- [ ] Eksport podsumowania i cytatów
