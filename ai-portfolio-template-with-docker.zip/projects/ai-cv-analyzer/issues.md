# Checklist — Zadania

- [ ] MVP: upload CV (.pdf/.docx) i link do ogłoszenia
- [ ] Ekstrakcja tekstu z CV i ogłoszenia
- [ ] Ocena dopasowania + rekomendacje zmian
- [ ] Eksport raportu (PDF/Markdown)
- [ ] Demo online i README z case study
