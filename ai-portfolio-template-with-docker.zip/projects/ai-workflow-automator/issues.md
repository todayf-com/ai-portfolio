# Checklist — Zadania

- [ ] MVP: definicja prostego workflow tekstowego
- [ ] Parser poleceń i mapowanie na zadania
- [ ] Obsługa arkusza Excel (import/eksport)
- [ ] Generowanie raportu PDF
- [ ] Kolejka zadań (worker)
