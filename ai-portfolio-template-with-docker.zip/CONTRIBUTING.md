# Contributing

1. Twórz branche per funkcja: `feat/<projekt>-<krotki-opis>`
2. Dodawaj testy i aktualizuj dokumentację.
3. Rób PR z czytelnym opisem (problem, rozwiązanie, screeny/demo).
